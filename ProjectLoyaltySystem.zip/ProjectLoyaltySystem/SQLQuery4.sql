﻿SELECT Username, Password
FROM Users
WHERE Username IN ('ramy', 'elamir');