﻿using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace YourNamespace.Data
{
    public class PointsDbContext : DbContext
    {
        public PointsDbContext(DbContextOptions<PointsDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Point> Points { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "ramy",
                    Password = HashPassword("gamal"),
                    Role = "Admin"
                },
                new User
                {
                    Id = 2,
                    Username = "elamir",
                    Password = HashPassword("elsady"),
                    Role = "Customer"
                }
            );
        }

        private static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }

    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }

    public class Point
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int Amount { get; set; }
        public User User { get; set; }
    }
}