﻿-- Inserting the user 'ramy'
INSERT INTO Users (Username, Password, Role)
VALUES ('ramy', 'gamal', 'Admin');

-- Inserting the user 'elamir'
INSERT INTO Users (Username, Password, Role)
VALUES ('elamir', 'elsady', 'Customer');