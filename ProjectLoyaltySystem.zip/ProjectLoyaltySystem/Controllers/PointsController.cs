﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using YourNamespace.Data;
using System;
using System.Linq;

namespace YourNamespace.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class PointsController : ControllerBase
    {
        private readonly PointsDbContext _context;

        public PointsController(PointsDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("create-user")]
        public IActionResult CreateUser([FromBody] User newUser)
        {
            try
            {
                _context.Users.Add(newUser);
                _context.SaveChanges();
                return Ok("User created successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error creating user: {ex.Message}");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("add-points/{userId}")]
        public IActionResult AddPoints(int userId, [FromBody] AddPointsRequest request)
        {
            var customer = _context.Users.SingleOrDefault(u => u.Id == userId);
            if (customer == null)
                return NotFound("User not found.");

            var points = new Point { UserId = userId, Amount = request.Amount };
            _context.Points.Add(points);
            _context.SaveChanges();

            return Ok("Points added successfully.");
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("view-points/{userId}")]
        public IActionResult ViewPoints(int userId)
        {
            var points = _context.Points.Where(p => p.UserId == userId).Sum(p => p.Amount);
            return Ok($"User {userId} has {points} points.");
        }

        [HttpGet("my-points")]
        public IActionResult MyPoints()
        {
            var username = User.Identity.Name;
            var customer = _context.Users.SingleOrDefault(u => u.Username == username);
            if (customer == null)
                return NotFound("User not found.");

            var points = _context.Points.Where(p => p.UserId == customer.Id).Sum(p => p.Amount);
            return Ok($"You have {points} points.");
        }

        [HttpPost("withdraw-points")]
        public IActionResult WithdrawPoints([FromBody] WithdrawPointsRequest request)
        {
            var username = User.Identity.Name;
            var customer = _context.Users.SingleOrDefault(u => u.Username == username);
            if (customer == null)
                return NotFound("User not found.");

            var points = _context.Points.Where(p => p.UserId == customer.Id).Sum(p => p.Amount);
            if (points < request.Amount)
                return BadRequest("Not enough points.");

            var withdrawal = new Point { UserId = customer.Id, Amount = -request.Amount };
            _context.Points.Add(withdrawal);
            _context.SaveChanges();

            return Ok("Points withdrawn successfully.");
        }

        [HttpPost("redeem-points")]
        public IActionResult RedeemPoints([FromBody] RedeemPointsRequest request)
        {
            var username = User.Identity.Name;
            var customer = _context.Users.SingleOrDefault(u => u.Username == username);
            if (customer == null)
                return NotFound("User not found.");

            var points = _context.Points.Where(p => p.UserId == customer.Id).Sum(p => p.Amount);
            if (points < request.Amount)
                return BadRequest("Not enough points.");

            var redemption = new Point { UserId = customer.Id, Amount = -request.Amount };
            _context.Points.Add(redemption);
            _context.SaveChanges();

            return Ok("Points redeemed successfully.");
        }
    }

    public class AddPointsRequest
    {
        public int Amount { get; set; }
    }

    public class WithdrawPointsRequest
    {
        public int Amount { get; set; }
    }

    public class RedeemPointsRequest
    {
        public int Amount { get; set; }
    }
}